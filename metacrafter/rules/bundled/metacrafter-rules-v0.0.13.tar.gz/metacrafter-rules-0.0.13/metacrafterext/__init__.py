__author__ = "Ivan Begtin"
__version__ = '0.0.13'
__license__ = "Apache"
__doc__ = "Metacrafter rules and validation functions"
