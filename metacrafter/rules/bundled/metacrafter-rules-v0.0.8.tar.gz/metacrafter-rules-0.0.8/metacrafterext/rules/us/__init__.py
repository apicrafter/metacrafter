"""
US-specific validation functions.
"""

