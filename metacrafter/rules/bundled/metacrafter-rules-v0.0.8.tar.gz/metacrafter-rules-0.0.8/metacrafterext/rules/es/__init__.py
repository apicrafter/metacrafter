"""
Spanish-specific validation functions.
"""

