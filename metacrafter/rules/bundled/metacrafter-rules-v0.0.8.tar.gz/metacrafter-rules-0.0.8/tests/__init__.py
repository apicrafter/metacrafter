# Tests for metacrafter-rules

